const { MongoClient } = require('mongodb');

const uri = "mongodb://127.0.0.1:27017/productsDB";
const client = new MongoClient(uri);
let db, productsCollection;

// Connect to MongoDB
async function connectToMongoDB() {
  try {
    await client.connect();
    db = client.db('productsDB');
    productsCollection = db.collection('products');
    console.log("Connected to MongoDB");
  } catch (err) {
    console.error("MongoDB connection error:", err);
    throw err;
  }
}

// Generate 10-character ID
async function generateId(type, brand) {
  const typePrefix = type.substring(0, 3).toUpperCase();
  const brandPrefix = brand.substring(0, 2).toUpperCase();
  const existingIds = await productsCollection
    .find({ id: new RegExp(`^${typePrefix}${brandPrefix}`) })
    .toArray();
  const ids = existingIds.map(p => parseInt(p.id.slice(5)));
  const num = ids.length ? Math.max(...ids) + 1 : 1;
  return `${typePrefix}${brandPrefix}${num.toString().padStart(5, '0')}`;
}

// Fetch all components (no pagination or sorting)
async function getComponents() {
  return await productsCollection.find().toArray();
}

// Fetch a single component by ID
async function getComponentById(id) {
  return await productsCollection.findOne({ id });
}

// Add a new component
async function addComponent(component) {
  await productsCollection.insertOne(component);
}

// Update a component
async function updateComponent(id, updatedComponent) {
  await productsCollection.updateOne({ id }, { $set: updatedComponent });
}

// Delete a component
async function deleteComponent(id) {
  await productsCollection.deleteOne({ id });
}

// Delete multiple components by IDs
async function deleteComponentsByIds(ids) {
  await productsCollection.deleteMany({ id: { $in: ids } });
}

// Delete all components
async function deleteAllComponents() {
  await productsCollection.deleteMany({});
}

// Search components
async function searchComponents({ q, type, priceMin, priceMax, brand }) {
  const query = {};

  if (q) {
    query.$or = [
      { name: { $regex: q, $options: 'i' } },
      { brand: { $regex: q, $options: 'i' } },
      { specifications: { $regex: q, $options: 'i' } }
    ];
  }
  if (type) query.type = type;
  if (brand) query.brand = brand;
  if (priceMin || priceMax) {
    query.price = {};
    if (priceMin) query.price.$gte = parseFloat(priceMin);
    if (priceMax) query.price.$lte = parseFloat(priceMax);
  }

  return await productsCollection.find(query).toArray();
}

// Initialize the connection when the module is loaded
connectToMongoDB();

module.exports = {
  getComponents,
  getComponentById,
  addComponent,
  updateComponent,
  deleteComponent,
  deleteComponentsByIds,
  deleteAllComponents,
  searchComponents,
  generateId
};