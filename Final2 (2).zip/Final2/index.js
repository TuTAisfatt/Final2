const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./public/javascripts/mongodb.js');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
  res.redirect('/pages/home.html');
});

// Read: Fetch all components (no pagination or sorting)
app.get('/components', async (req, res) => {
  try {
    const products = await db.getComponents();
    res.json(products);
  } catch (err) {
    res.status(500).send('Error fetching components');
  }
});

// Read: Fetch a single component
app.get('/component/:id', async (req, res) => {
  try {
    const product = await db.getComponentById(req.params.id);
    if (product) {
      res.json(product);
    } else {
      res.status(404).send('Component not found');
    }
  } catch (err) {
    res.status(500).send('Error fetching component');
  }
});

// Create: Add a new component
app.post('/create', async (req, res) => {
  const { name, type, brand, specifications, price, status, image } = req.body;
  try {
    const id = await db.generateId(type, brand);
    const newComponent = {
      id,
      name,
      type,
      brand,
      specifications,
      price: parseFloat(price),
      status,
      image: image || 'default.jpg'
    };
    await db.addComponent(newComponent);
    res.redirect('/pages/home.html');
  } catch (err) {
    res.status(500).send('Error adding component');
  }
});

// Update: Update a component
app.post('/update/:id', async (req, res) => {
  const { name, type, brand, specifications, price, status, image } = req.body;
  const updatedComponent = {
    name,
    type,
    brand,
    specifications,
    price: parseFloat(price),
    status,
    image: image || 'default.jpg'
  };

  try {
    await db.updateComponent(req.params.id, updatedComponent);
    res.redirect('/pages/home.html');
  } catch (err) {
    res.status(500).send('Error updating component');
  }
});

// Delete: Delete a component
app.post('/delete/:id', async (req, res) => {
  try {
    await db.deleteComponent(req.params.id);
    res.redirect('/pages/home.html');
  } catch (err) {
    res.status(500).send('Error deleting component');
  }
});

// Delete: Delete multiple components
app.post('/delete-selected', async (req, res) => {
  try {
    const ids = JSON.parse(req.body.ids); // Parse the JSON string of IDs
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).send('No components selected for deletion');
    }
    await db.deleteComponentsByIds(ids);
    res.redirect('/pages/home.html');
  } catch (err) {
    res.status(500).send('Error deleting selected components');
  }
});

// Delete: Delete all components
app.post('/delete-all', async (req, res) => {
  try {
    await db.deleteAllComponents();
    res.redirect('/pages/home.html');
  } catch (err) {
    res.status(500).send('Error deleting all components');
  }
});

// Search: Handle search queries
app.get('/search', async (req, res) => {
  const { q, type, priceMin, priceMax, brand } = req.query;
  try {
    const products = await db.searchComponents({ q, type, priceMin, priceMax, brand });
    res.json(products);
  } catch (err) {
    res.status(500).send('Error searching components');
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});